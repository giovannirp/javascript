import { NumeroDirective } from './numero.directive';

describe('NumeroDirective', () => {
  it('should create an instance', () => {
    const directive = new NumeroDirective();
    expect(directive).toBeTruthy();
  });
});
